open Yojson.Basic
open Parser
open Task
open Datadriver

let dataFile = "data_prep.json" 

let s  = "\nDescription:" ^ String.make 23 ' '^ "Due Date:" ^  "     " ^"Due Time:   " 
         ^ "Completed:   " ^ "Priority:   " ^ "Category:\n\n"




let print_instructions () = 
  print_endline "\n\n\"make  [deadline] [priority] [description]\": creates a task";
  print_endline "\ Deadline is in MM/DD/YYYY hh:mm format, with times in 24-hour format";
  print_endline "\ The deadline field is optional";
  print_endline "\ Priority is an int from 1 to 10, with 10 being a very important";
  print_endline "\ or time-consuming task, and 1 being not very important or time-consuming";
  print_endline "\"complete [taskId]\" or \"complete [description]\": marks a task as completed";
  print_endline "\"remove [taskId]\" or \"remove [description]\": removes a task permanently";
  print_endline "\"futureDue\": prints all future tasks";
  print_endline "\"toDo\": The recommended order to complete tasks"; 
  print_endline "\"completedTasks\": prints all completed tasks";
  print_endline "\"overdue\": prints all overdue tasks ";
  print_endline "\"seeAll\": prints all tasks";
  print_endline "\"see [taskId]\" or \"see [description]\": prints the task with that taskid 
  or description respectively color coded to indicate the urgency of the task.
  If a task is not completed with a deadline, red means the task is due within 
  1 day and yellow means the task is due in more than a day.
  If a task is completed then it is green regardless of whether or not it has a deadline.
  If a task is overdue or incomplete without having a deadline it is white. ";
  print_endline "\"help\": to see this message again "; 
  print_endline "\"quit\": exits scheduler\" \n\n "

(** [game_loop st] is the basic game loop that updates state [st] in the
    adventure game from file [f]. *)
let rec main_loop () =

  ANSITerminal.(print_string [cyan]
                  "\n\nPlease enter a command.\n\n");
  print_string  "> ";

  let command = read_line () in

  match parse command with 
  | Quit -> print_endline "Okay, bye!";
    exit 0
  | MakeTask (deadline, priority, description, tags) -> begin
      try let NextId(_,id) = Datadriver.get_variable dataFile "next_id" in
        add_task dataFile (make (id) (description) false deadline tags (priority));
        let j = from_file dataFile in print_endline(new_str_oflst j);
        main_loop();
      with DuplicateDescription (x) ->
        print_endline ("A task with description \""^x^"\" already exists");
        main_loop();
         | InvalidDescription (_) ->
           print_endline "A task cannot have a description that begins with the
            '#' character.";
           main_loop () end
  | CompleteTask id -> begin
      try update_property_by_id dataFile id (Task.Completed(true)); 
        let j = from_file dataFile in print_endline(new_str_oflst j);
        main_loop();
      with InvalidId x-> print_string 
                           ("\nError: "^(string_of_int x) ^ " is not a valid id\n"); 
        (**  in remove_task dataFile id;  add_task dataFile t*)
        main_loop () end
  |CompleteTaskS desc -> begin 
      try let id = get_task_id_by_description dataFile desc in 
        update_property_by_id dataFile id (Task.Completed(true)); 
        let j = from_file dataFile in print_endline(new_str_oflst j);
        main_loop();
      with InvalidDescription x-> print_string 
                                    ("\nError: "^x ^ " is not a valid description\n"); 
        (**  in remove_task dataFile id;  add_task dataFile t*)
        main_loop () end
  | RemoveTask id -> begin
      try remove_task_by_id dataFile id;
        let j = from_file dataFile in print_endline(new_str_oflst j);
        main_loop();
      with InvalidId x-> print_string 
                           ("\nError: "^(string_of_int x) ^ " is not a valid id\n");
        main_loop ()
    end
  |RemoveTaskS desc -> begin
      try let id = get_task_id_by_description dataFile desc in 
        remove_task_by_id dataFile id;
        let j = from_file dataFile in print_endline(new_str_oflst j);
        main_loop();
      with InvalidDescription x-> print_string 
                                    ("\nError: "^x ^ " is not a valid description\n");
        main_loop () end
  | SeeTasks -> let j = from_file dataFile in 
    print_endline(new_str_oflst j |> String.trim); main_loop ()
  | Help ->   print_endline "\nHere are the commands again:\n";
    print_instructions();  main_loop ()
  | FutureDue ->
    print_endline(future_list dataFile |> String.trim); main_loop ()
  | Completed -> let j = from_file dataFile in 
    print_endline(completed_list j |> String.trim); main_loop ()
  (*| Help -> print_instructions () *)
  | SeeI id -> let j = from_file dataFile in 
    if (make_list j id) = s then 
      print_endline("\nError: "^(string_of_int id) ^ " is not a valid id\n") 
    else ANSITerminal.(print_string (color j id) ( (make_list j id) |> String.trim) ); 
    main_loop ()
  | SeeS description -> let j = from_file dataFile in 
    if (dmake_list j description) = s 
    then  print_endline("\nError: "^(description) ^ " is not a valid description\n")
    else ANSITerminal.(print_string (d_color j description)((dmake_list j description) 
                                                            |> String.trim) ); 
    main_loop ()
  |Overdue -> 
    print_endline(overdue_list dataFile |> String.trim); main_loop ()
  |DoNext ->  print_endline (next_to_do dataFile);
    main_loop();
  | exception Empty -> print_string "\nThis is an empty command!\n";
    main_loop ()
  | exception Malformed -> print_string "\nSorry, I didn't understand that.\n";
    main_loop ()

(** [main ()] prompts for the game to play, then starts it. *)
let main () =
  ANSITerminal.(print_string [cyan]
                  "\n\nWelcome to the Scheduler!\n");
  print_instructions (); 

  main_loop ()

(* Execute the game engine. *)
let () = main ()

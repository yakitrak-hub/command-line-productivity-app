open Unix
type object_phrase = string list

(**command variant to be used *)
type command = 
  | MakeTask of float option*int*string*string list
  | CompleteTask of int
  | CompleteTaskS of string
  | RemoveTask of int
  | RemoveTaskS of string
  | SeeTasks
  | FutureDue
  | Completed
  | SeeI of int 
  | SeeS of string
  | Help
  | Quit
  | Overdue
  | DoNext

(**not used outside of this class. Used to check if verb is valid *)
type tempCommand = 
  | TMakeTask of object_phrase
  | TCompleteTask of object_phrase
  | TRemoveTask of object_phrase
  | TSeeTasks
  | TFutureDue
  | TCompleted
  | TSee of object_phrase
  | TQuit
  | THelp
  | TOverdue
  | TDoNext

exception Empty

exception Malformed

(**[extend  s] takes a string of ints [s] and extends it to length 2 for
   prettier printing by prepending a 0*)
let extend (s:string):string =
  if String.length s < 2 then "0"^s else s

(** [readtime t] converts unix time [t] to a pretty printed 
    string of a human readable date relative to local time zone.
    Example: readtime 1555287178 returns "4/14/2019 20:12" *) 
let readtime (t:float):string =
  let date = localtime t in
  match date with 
  | {tm_sec = sec; tm_min = min; tm_hour = hour; tm_mday = day; tm_mon = month;
     tm_year = yr; tm_wday = w; tm_yday = y; tm_isdst = b} -> 
    let d  = extend (string_of_int (month + 1)) ^ "/" 
             ^ extend (string_of_int (day)) 
             ^ "/" ^ string_of_int (yr+1900) in let m = string_of_int(min) in
    d ^ " " ^ extend (string_of_int(hour)) ^ ":" ^ 
    (if String.length m =1 then (m ^"0") else m)

(**[make_unix_time] converts [(month,day,year)] and [(hour, minute) into the 
    Ocaml/unix time object] *)
let make_unix_time ((month, day, year):(int*int*int)) ((hour, minute):(int*int))
  = fst (Unix.mktime {Unix.tm_sec = 0; tm_min = minute; tm_hour = hour; 
                      tm_mday = day; tm_mon = month -1; tm_year = year -1900;
                      tm_wday = 0; tm_yday = 0; tm_isdst =false})


(** [is_valid_year] is whether int [y] is a valid year *)
let is_valid_year y = y >= 1

(** [is_valid_month] is whether string [m] is a valid month *)
let is_valid_month m = m >= 1 && m <= 12

(** [get_days_in_month] is the number of days in the month [m] 
    during year [y]*)
let get_days_in_month m y= 
  if m = 2 then
    if (y mod 400) = 0 then 29
    else if (y mod 100) = 0 then 28
    else if (y mod 4) = 0 then 29
    else 28

  else if List.mem m [1; 3; 5; 7; 8;10; 12] then 31

  else 30

(**[is_valid_day] is whether the int [d] is a valid day *)
let is_valid_day y m d = d >= 1 && d <= get_days_in_month m y 

(** [valid_date] returns whether [m] \ [d] \ [y] is valid *)
let valid_date y m d =
  is_valid_year y && is_valid_month m && is_valid_day y m d

(**[string_to_date] converts [dueDate] ("MM/DD/YYYY") into (month,day,year)
    Raises [Malformed] if dueDate in incorrect format *)
let string_to_date (dueDate:string):int*int*int = 
  let date = String.split_on_char '/' dueDate in
  match date with
  |month::day::year::[] -> int_of_string month, int_of_string day, 
                           int_of_string year
  | _ -> raise Malformed

(**[is_valid_due_date]  checks whether a [dueDate] contains a valid date*)
let is_valid_due_date (dueDate:string) = 
  try let (month,day,year) = string_to_date dueDate in
    valid_date year month day 
  with _ -> false

(**[string_to_time] converts dueTime of format "HH:MM" into [(hour,mminute)]
   Raises [Malformed] if dueTime is in  incorrect format *)
let string_to_time (dueTime:string): int*int = 
  let time = String.split_on_char ':' dueTime in match time with
  |hour::minute::[] -> int_of_string hour, int_of_string minute 
  | _ -> raise Malformed 

(**[is_valid_due_time] checks if [dueTime] contains a valid time  *)
let is_valid_due_time (dueTime: string)= 
  try let (hour, minute ) = string_to_time dueTime in
    hour >= 0 && hour < 24 && minute >= 0 && minute < 60
  with _ -> false

(**[is_valid_description] checks if a task is description isn't empty *)
let is_valid_description (description: string) = description <> "" 

(**[is_valid_task_id] checks if [id] > 0*)
let is_valid_task_id (id:int) =  id>0

(**[is_valid_priority priority] checks that the priority is an int between 1 and
   10  *)
let is_valid_priority (priority:int)= priority >0 &&priority < 11

let getDescriptionAndTags descriptionandtagslist = 

  let rec helper (description, tags) lst = match lst with
    |[] -> (description,tags)
    |h::t -> if h.[0] = '#' then helper (description, h::tags) t else 
        helper (description@[h] , tags) t  in
  helper ([], []) descriptionandtagslist

(**[parse] will parse [phrase] with a (potential) command and returns
   the appropriate Command variant.
   Raises: Empty,     if [phrase]  = ""
          Malformed,  if [phrase] is not in the correct format*)
let parse (phrase:string) =
  let tokenStreamWithWhiteSpaces = String.split_on_char ' ' phrase in

  let rec removeWhiteSpaces = function
    |[] -> []
    |h::t -> if h = "" then (removeWhiteSpaces t) else h:: (removeWhiteSpaces t)
  in 

  let tokenStream = removeWhiteSpaces tokenStreamWithWhiteSpaces in

  match tokenStream with
  | [] -> raise Empty
  | verb::inputs ->

    (**checks if verb is correct *)
    let userCommand = match verb with
      | "make" -> TMakeTask inputs
      | "complete" ->  TCompleteTask inputs 
      | "remove" -> TRemoveTask inputs
      | "seeAll" -> if inputs = [] then TSeeTasks else raise Malformed
      | "futureDue" -> if inputs = [] then TFutureDue else raise Malformed
      | "completedTasks" -> if inputs = [] then TCompleted else raise Malformed
      | "see" -> TSee inputs
      | "help" -> if inputs = [] then THelp else raise Malformed
      | "quit" -> TQuit
      | "overdue" -> TOverdue
      | "toDo" -> TDoNext
      | _ -> raise Malformed    
    in

    (*checks if inputs are correct *)
    match userCommand with
    | TOverdue -> Overdue
    | TMakeTask inputs -> begin
        match inputs with
        |dueDate::dueTime::priority::descriptionTags  -> begin
            let (description, tags) = getDescriptionAndTags descriptionTags in 
            try let p = int_of_string (String.trim priority) in
              let description = String.concat " " description in 
              if  is_valid_due_date dueDate && 
                  is_valid_due_time dueTime && is_valid_description description 
                  && is_valid_priority p
              then MakeTask (Some (make_unix_time (string_to_date dueDate) 
                                     (string_to_time dueTime)),p, description,tags)
              else raise Malformed
            with Failure(_) ->
            try let p = int_of_string (String.trim dueDate) in
              let descriptionAndTags = (dueTime::priority::descriptionTags) in
              let (d, t)  = getDescriptionAndTags descriptionAndTags in 
              let d = String.concat " " d in 
              if is_valid_priority p && 
                 is_valid_description d
              then MakeTask (None,p,d, t)
              else raise Malformed
            with Failure(_) ->
              raise Malformed end
        |priority::descriptionAndTags -> begin
            try let p = int_of_string (String.trim priority) in
              let (description, tags) = getDescriptionAndTags descriptionAndTags 
              in let description = String.concat " " description in 
              if is_valid_description description &&
                 is_valid_priority p then 
                MakeTask(None, p, description, tags)
              else raise Malformed
            with Failure(_)->
              raise Malformed end
        |_-> raise Malformed end
    | TCompleteTask inputs -> begin try if (List.length inputs <> 1) ||
                                           not (is_valid_task_id 
                                                  (int_of_string (List.hd inputs)))
          then let desc = (String.concat " " inputs) in 
            if (is_valid_description desc)
            then CompleteTaskS desc
            else raise Malformed 
          else CompleteTask (int_of_string (List.hd inputs)) 
        with Failure(_)-> 
          let desc = (String.concat " " inputs) in if (is_valid_description desc)
          then CompleteTaskS desc
          else raise Malformed 
      end
    | TRemoveTask inputs -> begin try if (List.length inputs <> 1) ||
                                         not (is_valid_task_id 
                                                (int_of_string (List.hd inputs)))
          then let desc = (String.concat " " inputs) in 
            if (is_valid_description desc)
            then RemoveTaskS desc
            else raise Malformed  
          else RemoveTask (int_of_string (List.hd inputs))
        with Failure (_)-> 
          let desc = (String.concat " " inputs) in if (is_valid_description desc)
          then RemoveTaskS desc
          else raise Malformed  
      end
    |TSeeTasks -> if inputs = [] then SeeTasks else raise Malformed
    |TFutureDue -> if inputs = [] then FutureDue else raise Malformed
    |TCompleted -> if inputs = [] then Completed else raise Malformed
    |THelp -> if inputs = [] then Help else raise Malformed
    |TSee inputs -> begin if (List.length inputs < 1) then raise Malformed else 
          try 
            (if (List.length inputs = 1 && 
                 is_valid_task_id (int_of_string (List.hd inputs))) then
               SeeI (int_of_string (List.hd inputs)) 
             else (let description = String.concat " " inputs in 
                   if is_valid_description description then SeeS description 
                   else raise Malformed ) )
          with 
          |Failure("int_of_string") ->
            (let description = String.concat " " inputs in 
             if is_valid_description description then SeeS description 
             else raise Malformed )  end
    |TQuit -> Quit
    |TDoNext -> DoNext



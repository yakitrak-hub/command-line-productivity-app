type updatable_property = 
  | Description of string
  | Completed of bool
  | Deadline of float option
  | Tags of string list
  | Priority of int

type t = 
  {id:int;
   description:string;
   completed:bool;
   deadline:float option;
   tags:string list;
   priority:int}

let id (task:t) : int = 
  task.id

let description (task:t) : string = 
  task.description

let completed (task:t) : bool = 
  task.completed

let deadline (task:t) : float option = 
  task.deadline

let tags (task:t) : string list = 
  task.tags

let priority (task:t): int =
  task.priority

let update_property (task:t) (property:updatable_property) : t = 
  match property with
  | Description(desc) -> {task with description=desc}
  | Completed(completed) -> {task with completed=completed}
  | Deadline(deadline) -> {task with deadline=deadline}
  | Tags(tags) -> {task with tags=tags}
  | Priority (priority)->{task with priority = priority}

(** [make id desc is_done deadline tags priority] constructs a [Task.t] with the 
    supplied properties. *)
let make (id:int) (desc:string) (is_done:bool)
    (deadline:float option) (tags:string list)(priority:int) : t = 
  {id=id;
   description=desc;
   completed=is_done;
   deadline=deadline;
   tags=tags;
   priority =priority }
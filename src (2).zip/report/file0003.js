var texts = new Array();
var states = new Array();

texts['fold000001'] = '<a href="javascript:fold(\'fold000001\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 1 to line 29</i>';
states['fold000001'] = false;
texts['fold000031'] = '<a href="javascript:fold(\'fold000031\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 31 to line 35</i>';
states['fold000031'] = false;
texts['fold000037'] = '<a href="javascript:fold(\'fold000037\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 37 to line 183</i>';
states['fold000037'] = false;
texts['fold000185'] = '<a href="javascript:fold(\'fold000185\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 185 to line 187</i>';
states['fold000185'] = false;
texts['fold000189'] = '<a href="javascript:fold(\'fold000189\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 189 to line 221</i>';
states['fold000189'] = false;
texts['fold000223'] = '<a href="javascript:fold(\'fold000223\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 223 to line 236</i>';
states['fold000223'] = false;
texts['fold000238'] = '<a href="javascript:fold(\'fold000238\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 238 to line 238</i>';
states['fold000238'] = false;
texts['fold000240'] = '<a href="javascript:fold(\'fold000240\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 240 to line 487</i>';
states['fold000240'] = false;
texts['fold000491'] = '<a href="javascript:fold(\'fold000491\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 491 to line 491</i>';
states['fold000491'] = false;
texts['fold000495'] = '<a href="javascript:fold(\'fold000495\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 495 to line 497</i>';
states['fold000495'] = false;
texts['fold000500'] = '<a href="javascript:fold(\'fold000500\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 500 to line 502</i>';
states['fold000500'] = false;
texts['fold000505'] = '<a href="javascript:fold(\'fold000505\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 505 to line 505</i>';
states['fold000505'] = false;
texts['fold000507'] = '<a href="javascript:fold(\'fold000507\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 507 to line 510</i>';
states['fold000507'] = false;
texts['fold000517'] = '<a href="javascript:fold(\'fold000517\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 517 to line 517</i>';
states['fold000517'] = false;
texts['fold000523'] = '<a href="javascript:fold(\'fold000523\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 523 to line 523</i>';
states['fold000523'] = false;
texts['fold000525'] = '<a href="javascript:fold(\'fold000525\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 525 to line 526</i>';
states['fold000525'] = false;
texts['fold000536'] = '<a href="javascript:fold(\'fold000536\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 536 to line 536</i>';
states['fold000536'] = false;
texts['fold000539'] = '<a href="javascript:fold(\'fold000539\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 539 to line 539</i>';
states['fold000539'] = false;

function fold(id) {
  tmp = document.getElementById(id).innerHTML;
  document.getElementById(id).innerHTML = texts[id];
  texts[id] = tmp;
  states[id] = !(states[id]);
}

function unfoldAll() {
  for (key in states) {
    if (states[key]) {
      fold(key);
    }
  }
}

function foldAll() {
  for (key in states) {
    if (!(states[key])) {
      fold(key);
    }
  }
}

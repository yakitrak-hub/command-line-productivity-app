var texts = new Array();
var states = new Array();

texts['fold000001'] = '<a href="javascript:fold(\'fold000001\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 1 to line 76</i>';
states['fold000001'] = false;
texts['fold000078'] = '<a href="javascript:fold(\'fold000078\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 78 to line 78</i>';
states['fold000078'] = false;
texts['fold000080'] = '<a href="javascript:fold(\'fold000080\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 80 to line 98</i>';
states['fold000080'] = false;
texts['fold000100'] = '<a href="javascript:fold(\'fold000100\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 100 to line 104</i>';
states['fold000100'] = false;
texts['fold000106'] = '<a href="javascript:fold(\'fold000106\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 106 to line 111</i>';
states['fold000106'] = false;
texts['fold000113'] = '<a href="javascript:fold(\'fold000113\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 113 to line 117</i>';
states['fold000113'] = false;
texts['fold000119'] = '<a href="javascript:fold(\'fold000119\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 119 to line 146</i>';
states['fold000119'] = false;
texts['fold000148'] = '<a href="javascript:fold(\'fold000148\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 148 to line 152</i>';
states['fold000148'] = false;
texts['fold000154'] = '<a href="javascript:fold(\'fold000154\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 154 to line 158</i>';
states['fold000154'] = false;
texts['fold000160'] = '<a href="javascript:fold(\'fold000160\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 160 to line 160</i>';
states['fold000160'] = false;
texts['fold000170'] = '<a href="javascript:fold(\'fold000170\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 170 to line 173</i>';
states['fold000170'] = false;
texts['fold000175'] = '<a href="javascript:fold(\'fold000175\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 175 to line 185</i>';
states['fold000175'] = false;
texts['fold000187'] = '<a href="javascript:fold(\'fold000187\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 187 to line 194</i>';
states['fold000187'] = false;
texts['fold000196'] = '<a href="javascript:fold(\'fold000196\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 196 to line 198</i>';
states['fold000196'] = false;
texts['fold000206'] = '<a href="javascript:fold(\'fold000206\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 206 to line 206</i>';
states['fold000206'] = false;
texts['fold000211'] = '<a href="javascript:fold(\'fold000211\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 211 to line 211</i>';
states['fold000211'] = false;
texts['fold000217'] = '<a href="javascript:fold(\'fold000217\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 217 to line 217</i>';
states['fold000217'] = false;
texts['fold000221'] = '<a href="javascript:fold(\'fold000221\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 221 to line 224</i>';
states['fold000221'] = false;
texts['fold000229'] = '<a href="javascript:fold(\'fold000229\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 229 to line 230</i>';
states['fold000229'] = false;
texts['fold000234'] = '<a href="javascript:fold(\'fold000234\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 234 to line 234</i>';
states['fold000234'] = false;
texts['fold000247'] = '<a href="javascript:fold(\'fold000247\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 247 to line 248</i>';
states['fold000247'] = false;
texts['fold000254'] = '<a href="javascript:fold(\'fold000254\');"><img border="0" height="10" width="10" src="plus.png" title="unfold code"/></a><i>&nbsp;&nbsp;code folded from line 254 to line 255</i>';
states['fold000254'] = false;

function fold(id) {
  tmp = document.getElementById(id).innerHTML;
  document.getElementById(id).innerHTML = texts[id];
  texts[id] = tmp;
  states[id] = !(states[id]);
}

function unfoldAll() {
  for (key in states) {
    if (states[key]) {
      fold(key);
    }
  }
}

function foldAll() {
  for (key in states) {
    if (!(states[key])) {
      fold(key);
    }
  }
}

open OUnit2
open Task
open Datadriver
open Yojson
open Parser

let test_json_file = "test_data.json"
let invalid_json_file = "invalid_data.json"
let initial_test_json_t = Yojson.Basic.from_file test_json_file

let example_task = ref (make 3 "Do homework" false (Some(1555718400.)) [] 1)
let example_task2 = ref (make 4 "Study for prelim" true (Some(1555718400.)) [] 2)
let example_task3 = ref (make 2 "Another task with id 2" false (Some(1555718400.)) [] 3)

let current_time = Unix.time()

(**[make_property_check_test name property_func task expected_value] takes a 
   function to check a property of a task and a task and ensures that the property
   returned by the function matches what is expected*)
let make_property_check_test 
    (name:string)
    (property_func:(Task.t -> 'a))
    (task:Task.t)
    (expected_value:'a) = 
  name >:: fun _ -> assert_equal (property_func task) (expected_value)

(**[make_update_property_test name property_func task new_property expected_val]
   makes sure that properties of a a given task are updated properly by the 
   function update_property*)
let make_update_property_test
    (name:string)
    (property_func:(Task.t -> 'a))
    (task:Task.t)
    (new_property:updatable_property)
    (expected_value:'a) = 
  name >:: fun _ -> example_task := update_property task new_property;
    ignore(make_property_check_test (name) (property_func) (task) (expected_value))

(**[make_get_task_by_id_test name task_id] makes sure the task returned by 
   get_task_by_id is the correct task*)
let make_get_task_by_id_test
    (name:string)
    (file:string)
    (task_id:int) = 
  name >:: fun _ -> ignore(make_property_check_test (name) (id) 
                             (get_task_by_id (file) (task_id)) (task_id)) 

(**[make_get_task_by_id_test name task_id expected_exn] makes sure that the
   expected exception is raised*)
let make_get_task_by_id_exn_test
    (name:string)
    (file:string)
    (task_id:int)
    (expected_exn:exn) = 
  name >:: fun _ -> assert_raises (expected_exn) (fun _ ->
      get_task_by_id file task_id)

(**[make_task_exists_with_id_test name task_id expected] makes sure the function
   task_exists_with_id returns the expected boolean value*)
let make_task_exists_with_id_test
    (name:string)
    (task_id:int)
    (expected:bool) =
  name >:: fun _ -> assert_equal expected (task_exists_with_id test_json_file task_id)

let make_get_tasks_by_tag
    (name:string)
    (tag:string)
    (exp_task_count:int) =
  name >:: fun _ -> assert_equal exp_task_count (List.length (get_tasks_by_tag test_json_file tag))

(**[make_add_task_test name task] makes sure that tasks can be added to the json
   file properly*)
let make_add_task_test
    (name:string)
    (task:Task.t) = 
  name >:: fun _ -> let added_task_id = id task in 
    add_task test_json_file task;
    assert_equal (get_task_by_id test_json_file (added_task_id)) (task)

(**[make_add_task_test_exn name task expected_exn] makes sure that attempting to
   add an invalid task to the .json file raises the expected exception*)
let make_add_task_test_exn
    (name:string)
    (task:Task.t)
    (expected_exn:exn) = 
  name >:: fun _ -> assert_raises (expected_exn) (fun _ -> 
      add_task test_json_file task)

let make_task_exists_with_desc
    (name:string)
    (desc:string)
    (exp_output:bool) =
  name >:: fun _ -> assert_equal exp_output (task_exists_with_description test_json_file desc)

(**[make_remove_task_test name task_id] makes sure that tasks can be removed 
   from the json file properly by their id*)
let make_remove_task_test
    (name:string)
    (task_id:int) =
  name >:: fun _ -> assert_bool ("task doesnt exist with supplied id") 
      (task_exists_with_id test_json_file task_id);
    remove_task_by_id test_json_file task_id;
    assert_raises (InvalidId(task_id)) 
      (fun _ -> get_task_by_id test_json_file task_id) 

(**[make_remove_task_test_exn name task expected_exn] makes sure that attempting 
   to remove an invalid id from the .json file raises the expected exception*)
let make_remove_task_test_exn
    (name:string)
    (task_id:int)
    (expected_exn) = 
  name >:: fun _ -> assert_raises (expected_exn)
      (fun _ -> remove_task_by_id test_json_file task_id)

(**[make_update_property_in_storage_test name task_id property] ensures that
   the task given by the task_id can have the given property updated properly *)
let make_update_property_in_storage_test
    (name:string)
    (task_id:int)
    (property:Task.updatable_property) = 
  name >:: fun _ ->
    ignore(update_property_by_id test_json_file task_id property);
    match property with
    | Description(desc) ->
      assert_equal (description (get_task_by_id test_json_file task_id)) (desc)
    | Deadline(due) -> 
      assert_equal (deadline (get_task_by_id test_json_file task_id)) (due)
    | Completed(cmplt) -> 
      assert_equal (completed (get_task_by_id test_json_file task_id)) (cmplt)
    | Tags (taglst) ->
      assert_equal (tags (get_task_by_id test_json_file task_id)) (taglst)
    | Priority (prior)->
      assert_equal (priority (get_task_by_id test_json_file task_id)) (prior)

(**[make_update_property_in_storage_exn_test name task_id property expected_exn]
   ensures that update_properties_in_storage raises the expected exception on 
   invalid inputs *)
let make_update_property_in_storage_exn_test
    (name:string)
    (task_id:int)
    (property:Task.updatable_property)
    (expected_exn) = 
  name >:: fun _ -> assert_raises (expected_exn) 
      (fun _ -> update_property_by_id test_json_file task_id property)

let make_add_tag_test
    (name:string)
    (id:int)
    (tag:string) = 
  name >:: fun _ -> 
    let curr_tag_count = List.length (get_tasks_by_tag test_json_file tag) in
    add_tag_to_task_by_id test_json_file id tag;
    assert_equal (curr_tag_count+1) (List.length (get_tasks_by_tag test_json_file tag)) 

let make_add_tag_test_exn
    (name:string)
    (id:int)
    (tag:string)
    (exp_exn:exn) =
  name >:: fun _ -> assert_raises exp_exn (fun _ -> add_tag_to_task_by_id test_json_file id tag)

let make_rem_tag_test
    (name:string)
    (id:int)
    (tag:string) = 
  name >:: fun _ -> let curr_tag_count = List.length (get_tasks_by_tag test_json_file tag) in
    remove_tag_from_task_by_id test_json_file id tag;
    assert_equal (curr_tag_count-1) (List.length (get_tasks_by_tag test_json_file tag)) 

let make_rem_tag_test_exn
    (name:string)
    (id:int)
    (tag:string)
    (exp_exn:exn) =
  name >:: fun _ -> assert_raises exp_exn (fun _ -> remove_tag_from_task_by_id test_json_file id tag)

(**[make_set_and_get_variable_test name variable new_val] ensures that variables
   are retrieved from and changed properly in the .json file *)
let make_set_and_get_variable_test
    (name:string)
    (variable:string)
    (new_val:Datadriver.variable) = 
  name >:: fun _ -> let current_val = get_variable test_json_file variable in 
    set_variable test_json_file new_val;
    assert_equal new_val (get_variable test_json_file variable);
    set_variable test_json_file current_val;
    assert_equal current_val (get_variable test_json_file variable)

(**[make_get_variable_exn_test  name variable expected_exn] ensures that 
   get_variable properly raises an exception*)
let make_get_variable_exn_test
    (name:string)
    (file:string)
    (variable:string)
    (expected_exn:exn) = 
  name >:: fun _ -> assert_raises (expected_exn) 
      (fun _ -> get_variable file variable)

(**[readtime_test name time expected] makes sure that the function readtime in 
   parser.ml correctly converts the Unix float time to a string*)
let readtime_test
    (name:string)
    (time:float)
    (expected:string) = 
  name >:: fun _-> assert_equal expected (readtime time)

(**[parse_maketask_test name input expected] is the OUnit function to ensure
   that the user input make works properly and that parser correctly parses 
   commands.*)
let parse_test
    (name:string)
    (input:string)
    (expected:(command)) =
  name>:: fun _-> let parsed_input = Parser.parse input in
    match expected with 
    | MakeTask(exp_timestamp, exp_priority, exp_task_desc, exp_tags) ->
      begin match parsed_input with
        | MakeTask(timestamp, priority, task_desc, tags) -> 
          assert_equal exp_timestamp timestamp;
          assert_equal exp_priority priority;
          assert_equal exp_task_desc task_desc;
          assert_equal exp_tags tags;
        |_ -> failwith "not equal"
      end
    |RemoveTask (exp_int) -> 
      (match parsed_input with 
       |RemoveTask(int)-> assert_equal exp_int int;
       |_-> failwith "not_equal";)
    |SeeTasks -> 
      (match parsed_input with 
       |SeeTasks->assert_equal 1 1;
       |_-> failwith "not equal")
    |FutureDue -> 
      (match parsed_input with 
       |FutureDue->assert_equal 1 1;
       |_-> failwith "not equal")
    |Completed -> 
      (match parsed_input with 
       |Completed->assert_equal 1 1;
       |_-> failwith "not equal")
    |SeeI exp_int -> 
      (match parsed_input with 
       |SeeI int->assert_equal exp_int int;
       |_-> failwith "not equal")
    |SeeS exp_str -> 
      (match parsed_input with 
       |SeeS str->assert_equal exp_str str;
       |_-> failwith "not equal";)        
    |_-> failwith "unimplemented"

let parse_test_exn
    (name:string)
    (input:string)
    (expected_exn:exn) = 
  name >:: fun _ -> assert_raises expected_exn (fun _ -> Parser.parse input)

(**Test cases for task.ml functions property_check and update_property *)
let task_tests = [
  make_property_check_test "correct description" description !example_task "Do homework"; 
  make_property_check_test "correct deadline" deadline !example_task (Some(1555718400.));
  make_property_check_test "correct completed" completed !example_task false;

  make_update_property_test ("update desc") (description) (!example_task) 
    (Description("Study for quiz")) ("Study for quiz");
  make_update_property_test ("update completed") (completed) (!example_task) 
    (Completed(true)) (true);
  make_update_property_test ("update deadline") (deadline) (!example_task) 
    (Deadline(Some(current_time))) (Some(current_time));
  make_update_property_test ("update tags") (tags) (!example_task) 
    (Tags(["life";"work"])) (["life";"work"]);
]

(**Test cases for datadriver.ml functions get_task_by_id, task_exists_with_id, 
   add_task, update_property_in_storage, remove_task, and make_set_and_get_variable
   to ensure they behave as expected and raise exceptions properly*)
let datadriver_tests = [
  make_get_task_by_id_test "get task id 0" test_json_file 0;

  make_get_task_by_id_exn_test "get task id -1" test_json_file (-1) (InvalidId(-1));
  make_get_task_by_id_exn_test "get task id 9999999" test_json_file 999999 (InvalidId(999999));

  make_task_exists_with_id_test "task exists -1" (-1) (false);
  make_task_exists_with_id_test "task exists 0" (0) (true);
  make_task_exists_with_id_test "task exists 999999" (999999) (false);

  make_get_tasks_by_tag "get tasks with tag life" "life" 1;
  make_get_tasks_by_tag "get tasks with tag fun" "fun" 0;

  make_add_task_test "make example task test" !example_task;
  make_add_task_test "make example task 2 test" !example_task2;

  make_add_task_test_exn "make example task 3 test" !example_task3 
    (DuplicateId(id !example_task3));

  make_task_exists_with_desc "task exists with desc 1" "Do laundry" true;
  make_task_exists_with_desc "task exists with desc 2" "Do homework 2" true;
  make_task_exists_with_desc "task exists with desc 3" "this task doesnt exist" false;

  make_update_property_in_storage_test "update description task id 0" (0) 
    (Description("Updated task description!"));
  make_update_property_in_storage_test "update deadline task id 1" (1) 
    (Deadline(Some(current_time)));
  make_update_property_in_storage_test "update completed task id 2" (2) 
    (Completed(false));

  make_add_tag_test "add tag test 1" 1 "movies";
  make_add_tag_test "add tag test 2" 2 "health";

  make_add_tag_test_exn "add tag false test 1" 1 "movies" (DuplicateTag("movies"));
  make_add_tag_test_exn "add tag false test 2" 1 "#world peace" (InvalidTag("#world peace"));

  make_rem_tag_test "rem tag test 1" 1 "movies";
  make_rem_tag_test "rem tag test 2" 2 "health";

  make_rem_tag_test_exn "rem tag false test 1" 1 "super" (InvalidTag("super"));

  make_remove_task_test "remove task id 1" (1);
  make_remove_task_test "remove task id 2" (2);

  make_remove_task_test_exn "remove task false id 1" 999999 (InvalidId(999999));
  make_remove_task_test_exn "remove task false id 2" (-1) (InvalidId(-1));

  make_update_property_in_storage_exn_test "update description false id 1" (-1) 
    (Description("This is a test task")) (InvalidId(-1));
  make_update_property_in_storage_exn_test "update description false id 2" 
    (999999) (Description("This is a test task too")) (InvalidId(999999));

  make_set_and_get_variable_test "set and get next_id 1" "next_id" (NextId("next_id", 500));
  make_set_and_get_variable_test "set and get next_id 2" "next_id" (NextId("next_id", 42));

  make_get_variable_exn_test "get variable 'fake_var'" test_json_file "fake_var" 
    (InvalidVariable("fake_var"));
  make_get_variable_exn_test "get variable 'cool_var'" test_json_file "cool_var" 
    (InvalidVariable("cool_var"));
]

(**Test cases for parser to ensure that readtime and parse functions work 
   properly *)
let parser_tests = [
  readtime_test "RT Test 1" 1555287178. "04/14/2019 20:12";
  readtime_test "RT Test 2"  951782340. "02/28/2000 18:59";
  readtime_test "RT Test 3"  1555475562. "04/17/2019 00:32";
  readtime_test "RT Test 4" 974613637. "11/19/2000 01:00";
  readtime_test "RT Test 5" (-2555512200.) "01/07/1889 02:30";
  readtime_test "RT Test 6" (-1555512240.) "09/16/1920 05:16";
  readtime_test "RT Test 7" (1456734600.) "02/29/2016 03:30";
  parse_test "Parse Test 1" "make 4/14/2019 20:12 1 test" 
    ((MakeTask (Some(1555287120.), 1, "test", [])));
  parse_test "Parse Test 2" "make 1/1/1970 0:00 1 test2" 
    (MakeTask (Some(18000.), 1, "test2", []));
  parse_test "Parse Test 3" "make 2/29/2016 3:30 1 test3" 
    (MakeTask (Some(1456734600.), 1, "test3", []));
  parse_test "Parse Test 4" "make 1/7/1889 2:30 1 test4" 
    (MakeTask (Some(-2555512200.), 1, "test4", []));
  parse_test "Parse Test 5" "make 9/16/1920 5:16 1 test5" 
    (MakeTask (Some(-1555512240.), 1, "test5", []));
  parse_test "Parse Test 6" "make 2/29/2000 3:00 1 test6" 
    (MakeTask (Some(951811200.), 1, "test6", []));
  parse_test "Parse Test 7" "make 2/29/2000 3:00 2 test7 #test" 
    (MakeTask (Some(951811200.), 2, "test7", ["#test"]));
  parse_test "Parse Test 8" "make 9 test8 #test" 
    (MakeTask (None, 9, "test8", ["#test"]));
  parse_test "Parse Test 9" "make 10 test9 #test #testing" 
    (MakeTask (None, 10, "test9", ["#testing";"#test"]));
  parse_test "Parse Test 10" "remove 10" 
    (RemoveTask 10);
  parse_test "Parse Test 11" "seeAll" 
    (SeeTasks);

  parse_test_exn "Parse false test 1" "make 2/35/20000 5:75 test" Malformed;
]

let tests = "test suite" >::: List.flatten [
    parser_tests;
    task_tests;
    datadriver_tests;
  ]

let _ = run_test_tt_main tests

let _ = Yojson.Basic.to_file test_json_file initial_test_json_t